Game Still in production
Use arrowkeys/WADS to move
go through the multiple classroom doors
Object of Game:
	Show up to classes and level up skills in those classes
	then take on Quarterlies (mini-bosses)
	when you think you are the master of the couse take the final to pass the class (boss)
Concept created by John Mendoza
Game created by Joey Yannuzzi