﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;
    public Text text;
    private System.String Tag;
    //private char t;
    //private System.String under;
	void Start () {

        rb2d = GetComponent<Rigidbody2D>();
	}
	
	void FixedUpdate() {

        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        Vector2 move = new Vector2(horizontal, vertical);
        rb2d.AddForce(move * speed);
	}

     void OnTriggerEnter2D(Collider2D other)
    {
        //t = Tag[0];
        //Tag = other.gameObject.tag;

        if (other.gameObject.CompareTag("_" + other.gameObject.name))
        {
            SceneManager.LoadScene(other.gameObject.tag, LoadSceneMode.Single);
        }

        else
        {
            text.text = other.gameObject.tag;
        }
    }
}
